from distutils.core import setup


setup(
	name='od2tex',
	version='0.5',
	description='Transliteration to Odia-TeX Converter',
	url='https://github.com/nsoum/odia-tex',
	author='Soumyashant Nayak',
	author_email='odia.bhashakosha@gmail.com',
	license='GNU General Public License',
	scripts=['od2tex'],
	packages=['od2tex-data'],
	package_data= {
		'od2tex-data': ['*']
	},
	
    )
